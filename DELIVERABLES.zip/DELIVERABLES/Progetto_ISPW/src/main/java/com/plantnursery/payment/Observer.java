package com.plantnursery.payment;

public abstract class Observer {

    protected abstract void update();
}
