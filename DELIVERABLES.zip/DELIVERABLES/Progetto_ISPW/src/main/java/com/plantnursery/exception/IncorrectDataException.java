package com.plantnursery.exception;

public class IncorrectDataException extends Exception{

    public IncorrectDataException(String message){
        super(message);
    }

}
