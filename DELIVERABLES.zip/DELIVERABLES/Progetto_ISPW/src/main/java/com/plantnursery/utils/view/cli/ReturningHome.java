package com.plantnursery.utils.view.cli;

public class ReturningHome {

    private Boolean returning;

    public ReturningHome() {
        this.returning = false;
    }

    public void setReturning(Boolean returning) {
        this.returning = returning;
    }

    public Boolean getReturning() {
        return returning;
    }

}
