package com.plantnursery.utils.dao.factory;

public enum TypeDAO {
    JDBC, FS;
}