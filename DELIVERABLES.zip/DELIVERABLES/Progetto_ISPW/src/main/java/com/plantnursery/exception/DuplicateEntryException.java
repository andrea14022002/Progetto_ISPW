package com.plantnursery.exception;

public class DuplicateEntryException extends Exception{

    public DuplicateEntryException(String message){
        super(message);
    }
}
