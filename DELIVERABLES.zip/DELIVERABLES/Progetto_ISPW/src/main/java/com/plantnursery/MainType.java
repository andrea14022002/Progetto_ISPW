package com.plantnursery;

public enum MainType {
    FX, CLI;
}
