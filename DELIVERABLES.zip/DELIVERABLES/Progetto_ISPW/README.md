Questo progetto è stato sviluppato nell'ambito del corso di Ingegneria del Software e Progettazione Web, presso l'Università degli Studi di Roma "Tor Vergata".
